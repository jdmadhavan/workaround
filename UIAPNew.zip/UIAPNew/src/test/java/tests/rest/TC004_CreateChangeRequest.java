package tests.rest;

import java.io.File;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import lib.rest.RESTAssuredBase;


public class TC004_CreateChangeRequest extends RESTAssuredBase{

	@BeforeTest
	public void setValues() {
		testCaseName = "Create a new ChaneRequest (REST)";
		testDescription = "Create a new ChngeRequest and Verify";
		nodes = "CR";
		authors = "Madhavan";
		category = "UI";
		dataFileName = "TC004";
		dataFileType = "JSON";
	}

	@Test(dataProvider = "fetchData")
	public void createIncident(File file) {		
		
		// Post the request
		Response response = postWithBodyAsFileAndUrl(file,"table/change_request");
				
		//Verify the Content by Specific Key
		verifyContentWithKey(response, "result.short_description", "Ragu");
		
		// Verify the Content type
		verifyContentType(response, "JSON");
		
		// Verify the response status code
		verifyResponseCode(response, 201);	
		
		// Verify the response time
		verifyResponseTime(response, 20000);
		
	}


}





