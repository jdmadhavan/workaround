package tests.selenium;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import lib.selenium.PreAndPost;

import pages.selenium.LaunchPage;

public class TC001_LoginAndLogout extends PreAndPost{

	@BeforeTest
	public void setValues() {
		testCaseName = "Login & Logout";
		testDescription = "Log in & Logout";
		nodes = "Login to Application";
		authors = "MDN";
		category = "UI";
		}

	@Test()
	public void loginAndLogout() {
		
		new LaunchPage(driver,test)
		.clickSignInLink()
		.typeUserName()
		.typePassword()
		.clickingSignInButton()
		.myprofilePage();
	}


}





