package lib.selenium;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;



import io.restassured.RestAssured;
import lib.utils.DataInputProvider;
import lib.utils.HTMLReporter;

public class PreAndPost extends WebDriverServiceImpl{
	public String dataSheetName;	
	public Properties prop;
	static String username = "vijaya.g%40photoninfotech.net"; // Your username
    static String authkey = "u0efefb7d912fbdd";  // Your authkey
    static String testScore = "unset";
	
	
	@BeforeSuite
	public void beforeSuite() {
		startReport();
	}
	
	@BeforeClass
	public void beforeClass() {
		startTestCase(testCaseName, testDescription);		
	}
	
	@BeforeMethod()
	public void beforeMethod() throws FileNotFoundException, IOException {

		// Load the properties file
		Properties prop = new Properties();
		prop.load(new FileInputStream(new File("./src/test/resources/config.properties")));
		
		//for reports		
		startTestModule(nodes);
		test.assignAuthor(authors);
		test.assignCategory(category);
		HTMLReporter.svcTest = test;		
		
		// settings for launching browser
		System.out.println("Environment--->"+prop.getProperty("enviroment"));
		if(prop.getProperty("enviroment").equalsIgnoreCase("Desktop"))
		{
			System.out.println("you ar running in Desktop");
			System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
			System.setProperty("webdriver.chrome.silentOutput", "true");

			// Start browser
			webdriver = new ChromeDriver();
			driver = new EventFiringWebDriver(webdriver);
			driver.register(this);
			driver.manage().window().maximize();
			driver.get("https://"+prop.getProperty("appUrl"));
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
	
	}else {
		
		try
		{
		  System.out.println("Starting CBT Cloude");
		  DesiredCapabilities caps = new DesiredCapabilities();
	      caps.setCapability("name", "Open QA Americas Pharmacy");
	      caps.setCapability("build", "1.0");
	      caps.setCapability("browserName", "Chrome");
	      caps.setCapability("version", "72");
	      caps.setCapability("platform", "Windows 10");
	      caps.setCapability("screenResolution", "1366x768");
	      caps.setCapability("record_video", "true");	
	     
	     
	      newWebdriver=new RemoteWebDriver(new URL("http://" + username + ":" + authkey +"@hub.crossbrowsertesting.com:80/wd/hub"), caps);
	      newWebdriver.get("https://"+prop.getProperty("appUrl"));
	      System.out.println(((RemoteWebDriver) newWebdriver).getSessionId());
	      testScore = "pass"; 
		}catch(Exception ae) {
			ae.printStackTrace();
			testScore = "pass"; 
	}
	}
	}

	@AfterMethod
	public void afterMethod() {
		try {
		closeActiveBrowser();
		}catch (Exception e) {
			throw new SkipException("No Driver is available to Close");
		}
	}

	@AfterSuite
	public void afterSuite() {
		endResult();
	}

	@DataProvider(name="fetchData")
	public  Object[][] getData(){
		return DataInputProvider.getSheet(dataSheetName);		
	}	

	
	
}
