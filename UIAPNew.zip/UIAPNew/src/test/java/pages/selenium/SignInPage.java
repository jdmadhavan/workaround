package pages.selenium;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import com.aventstack.extentreports.ExtentTest;
import lib.selenium.PreAndPost;

public class SignInPage extends PreAndPost{

	public SignInPage(EventFiringWebDriver driver, ExtentTest test) {	
		this.driver = driver;
		this.test = test;	
		driver.switchTo().defaultContent();
		PageFactory.initElements(driver, this);
		
		prop = new Properties();
		try {
			prop.load(new FileInputStream(new File("./src/test/resources/config.properties")));
		} catch (Exception e) {
			reportStep("Missing the configuration file", "FAIL");
		}
	}		

	
	
	@FindBy(id="edit-user-name") 
	private WebElement eleUserName;	
	public SignInPage typeUserName(){	
		type(eleUserName, prop.getProperty("username"));
		return this; 
	}	
	
	@FindBy(id="edit-password") 
	private WebElement elePaswd;	
	public SignInPage typePassword(){	
		type(elePaswd, prop.getProperty("password"));
		return this; 
	}
	
	
	@FindBy(id = "edit-submit")
	WebElement signInButton;
	public MyProfilePage clickingSignInButton() {
		//scrollToElem(signInButton);
		click(signInButton);
		return new MyProfilePage(driver,test);		
	}

}










